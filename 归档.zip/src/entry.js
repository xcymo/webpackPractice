import css from './css/index.css';
import less from './css/xcy.less'
let xcyString = "大噶好 我系古天乐"
document.write(xcyString);
document.write("<h1>欢迎来到 贪玩蓝月</h1>");